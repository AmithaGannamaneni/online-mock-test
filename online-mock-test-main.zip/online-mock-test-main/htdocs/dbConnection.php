<?php
$con= new mysqli('sql306.byetcluster.com','epiz_21997292','ihrao123','epiz_21997292_online')or die("Could not connect to mysql".mysqli_error($con));

?>